    $(document).ready(function(){
      var n = 0;
      var l = document.getElementById("number");
      var a = window.setInterval(function(){
        l.innerHTML = n;
        n++;
      },1000);


      var contador=30;
      var intervalo;
      var puntuacion;

      function tiempo(){
        intervalo=window.setInterval(mostrarTiempo,1000);

      }
      function mostrarTiempo(){
          if (contador > 0) {
            $("#contador").text("Tienes "+contador-- +" s");
          } else{
            //
          }
        }

      tiempo();

      $("#foto").click(function(){
        puntuacion=contador*10;
        contador=0;
        var tiempoTotal = n;
        clearInterval(intervalo);
        clearInterval(a);
        alert("Has encontrado al hombre de la antorcha!. Has conseguido "+puntuacion+" puntos.");
      });
    });